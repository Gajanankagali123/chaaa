# Chaarithraya Elevators Private Limited — Website

A premium, single-page, fully responsive website built with plain **HTML5, CSS3 and vanilla JavaScript** (no build tools, no frameworks required).

## 📁 Project Structure
```
chaarithraya-elevators/
├── index.html          → All page content & sections
├── css/
│   └── style.css       → Design tokens, layout, animations
├── js/
│   └── script.js       → Nav, scroll reveals, counters, product/project data, form
├── images/
│   └── favicon.svg      → Browser tab icon
└── README.md
```

## ▶️ How to run it in VS Code

1. Unzip the folder and open it in VS Code (`File → Open Folder…`).
2. Install the **Live Server** extension (by Ritwick Dey) from the Extensions panel if you don't have it.
3. Right-click `index.html` → **Open with Live Server**.
4. The site opens in your browser at `http://127.0.0.1:5500` and reloads automatically as you edit.

*(Alternatively, just double-click `index.html` to open it directly in any browser — everything works with zero setup.)*

## 🎨 What's included

- **Hero section** with a custom hand-built SVG/CSS animated glass elevator (cabin travels up and down, doors open/close, floor indicator, ambient particles, mouse parallax).
- **Sticky glass-blur navigation** that goes transparent → white on scroll, with a mobile slide-in menu.
- **About** section with mission/vision cards, a "why choose us" list, animated counters, and a timeline.
- **Products** grid (10 product types) with 3D tilt-on-hover cards and expandable "Read More" details.
- **Projects** masonry gallery with category filtering (Residential, Commercial, Industrial, Hospitals, Malls, Hotels, Offices).
- **Contact** section with an embedded Google Map, company details, and a validated enquiry form.
- Floating **WhatsApp**, **Call Now**, and **Back to Top** buttons.
- Scroll-reveal animations, animated counters, and reduced-motion support for accessibility.

## ✏️ Things to customize before going live

1. **Real photography** — the hero, about, and project visuals currently use bespoke SVG/CSS illustrations in the brand colors (kept dependency-free and instant-loading). Swap in real installation photos by replacing the `<svg>`/gradient blocks in `index.html` with `<img>` tags pointing to files in `/images`.
2. **Contact form submission** — the form in `#contactForm` (in `js/script.js`, function `contactFormHandler`) currently only validates and shows a thank-you message. Connect it to a real backend, or a service like [Formspree](https://formspree.io) or [EmailJS](https://www.emailjs.com/), so enquiries actually reach your inbox.
3. **Google Map** — the embedded map currently centers on "Bangalore". Replace the `src` URL of the `<iframe>` in the Contact section with your exact office location from Google Maps → Share → Embed a map.
4. **Phone/WhatsApp numbers** — update `tel:` and `wa.me` links in `index.html`/`script.js` if numbers change.
5. **Social links** — the `#` placeholders in the header/footer social icons should be replaced with your real Facebook/Instagram/LinkedIn/YouTube URLs.
6. **Logo** — `nav-logo-mark` is currently a styled "C•E" monogram. Replace with an `<img>` tag if you have a designed logo file.

## 🚀 Deploying

Because this is a static site, you can host it for free on:
- **Netlify** or **Vercel** — drag and drop the folder.
- **GitHub Pages** — push the folder to a repo and enable Pages.
- Or upload via FTP to any standard web hosting plan.

No server-side code or database is required for the front end itself (only the contact form needs a backend/service, per note above).

---
Built for **Chaarithraya Elevators Private Limited** — Bangalore · Mysore · Kodagu · Hassan.
