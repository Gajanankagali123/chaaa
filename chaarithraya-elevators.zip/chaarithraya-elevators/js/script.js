/* =========================================================
   CHAARITHRAYA ELEVATORS — SCRIPT
   Vanilla JS: no external dependencies, fast-loading.
   ========================================================= */
(function(){
  "use strict";

  document.addEventListener("DOMContentLoaded", init);

  function init(){
    setYear();
    preloader();
    navScroll();
    navToggleMenu();
    smoothLinkClose();
    revealOnScroll();
    counters();
    buildProducts();
    buildProjects();
    productTilt();
    heroParallax();
    contactFormHandler();
    backToTop();
    callButton();
    floorBadgeSync();
  }

  /* ---------- Footer year ---------- */
  function setYear(){
    var y = document.getElementById("year");
    if (y) y.textContent = new Date().getFullYear();
  }

  /* ---------- Preloader ---------- */
  function preloader(){
    var el = document.getElementById("preloader");
    if (!el) return;
    window.addEventListener("load", function(){
      setTimeout(function(){ el.classList.add("hide"); }, 350);
    });
    // fallback in case 'load' already fired
    setTimeout(function(){ el.classList.add("hide"); }, 2500);
  }

  /* ---------- Nav scroll state ---------- */
  function navScroll(){
    var nav = document.getElementById("siteNav");
    if (!nav) return;
    function onScroll(){
      if (window.scrollY > 40) nav.classList.add("scrolled");
      else nav.classList.remove("scrolled");
    }
    window.addEventListener("scroll", onScroll, { passive:true });
    onScroll();

    // active link highlight
    var sections = document.querySelectorAll("main section[id], main#home");
    var links = document.querySelectorAll(".nav-link");
    var byId = {};
    links.forEach(function(l){
      var id = l.getAttribute("href").replace("#","");
      byId[id] = l;
    });
    var observer = new IntersectionObserver(function(entries){
      entries.forEach(function(entry){
        if (entry.isIntersecting){
          links.forEach(function(l){ l.classList.remove("active"); });
          var link = byId[entry.target.id];
          if (link) link.classList.add("active");
        }
      });
    }, { rootMargin: "-45% 0px -50% 0px" });
    document.querySelectorAll("section[id]").forEach(function(s){ observer.observe(s); });
  }

  /* ---------- Mobile nav toggle ---------- */
  function navToggleMenu(){
    var toggle = document.getElementById("navToggle");
    var links = document.getElementById("navLinks");
    if (!toggle || !links) return;
    toggle.addEventListener("click", function(){
      var open = links.classList.toggle("open");
      toggle.setAttribute("aria-expanded", open ? "true" : "false");
    });
  }

  function smoothLinkClose(){
    var links = document.getElementById("navLinks");
    document.querySelectorAll(".nav-link").forEach(function(l){
      l.addEventListener("click", function(){
        if (links) links.classList.remove("open");
      });
    });
  }

  /* ---------- Reveal on scroll ---------- */
  function revealOnScroll(){
    var items = document.querySelectorAll("[data-reveal]");
    if (!items.length) return;
    var observer = new IntersectionObserver(function(entries){
      entries.forEach(function(entry){
        if (entry.isIntersecting){
          entry.target.classList.add("in-view");
          observer.unobserve(entry.target);
        }
      });
    }, { threshold: 0.15 });
    items.forEach(function(i){ observer.observe(i); });
  }

  /* ---------- Animated counters ---------- */
  function counters(){
    var nums = document.querySelectorAll(".hero-stat-num, .counter-num");
    if (!nums.length) return;
    var observer = new IntersectionObserver(function(entries){
      entries.forEach(function(entry){
        if (entry.isIntersecting){
          animateCount(entry.target);
          observer.unobserve(entry.target);
        }
      });
    }, { threshold: 0.6 });
    nums.forEach(function(n){ observer.observe(n); });
  }

  function animateCount(el){
    var target = parseInt(el.getAttribute("data-count"), 10) || 0;
    var suffix = el.getAttribute("data-suffix") || "";
    var duration = 1400;
    var start = null;

    function step(ts){
      if (!start) start = ts;
      var progress = Math.min((ts - start) / duration, 1);
      var eased = 1 - Math.pow(1 - progress, 3);
      el.textContent = Math.round(eased * target) + suffix;
      if (progress < 1) requestAnimationFrame(step);
      else el.textContent = target + suffix;
    }
    requestAnimationFrame(step);
  }

  /* ---------- Product data + render ---------- */
  var ICONS = {
    passenger: '<svg viewBox="0 0 24 24" fill="none" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"><rect x="5" y="2" width="14" height="20" rx="2"/><path d="M9 6h6M9 10h6M9 14h6"/></svg>',
    hospital: '<svg viewBox="0 0 24 24" fill="none" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"><rect x="4" y="3" width="16" height="18" rx="2"/><path d="M12 8v6M9 11h6"/></svg>',
    goods: '<svg viewBox="0 0 24 24" fill="none" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"><path d="M3 7l9-4 9 4-9 4-9-4Z"/><path d="M3 7v10l9 4 9-4V7M12 11v10"/></svg>',
    capsule: '<svg viewBox="0 0 24 24" fill="none" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"><rect x="7" y="2" width="10" height="20" rx="5"/><path d="M7 9h10M7 15h10"/></svg>',
    home: '<svg viewBox="0 0 24 24" fill="none" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"><path d="M3 11l9-8 9 8"/><path d="M5 10v10h14V10"/></svg>',
    mrl: '<svg viewBox="0 0 24 24" fill="none" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"><rect x="6" y="2" width="12" height="20" rx="2"/><path d="M6 8h12M10 12h4"/></svg>',
    hydraulic: '<svg viewBox="0 0 24 24" fill="none" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"><path d="M6 21V9l6-6 6 6v12"/><path d="M9 21v-6h6v6"/></svg>',
    car: '<svg viewBox="0 0 24 24" fill="none" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"><path d="M3 13l2-6h14l2 6"/><rect x="2" y="13" width="20" height="6" rx="2"/><circle cx="7" cy="19" r="1.4"/><circle cx="17" cy="19" r="1.4"/></svg>',
    escalator: '<svg viewBox="0 0 24 24" fill="none" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"><path d="M3 19h5l10-14h3"/><path d="M3 5h5l10 14h3"/></svg>',
    dumbwaiter: '<svg viewBox="0 0 24 24" fill="none" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"><rect x="8" y="2" width="8" height="20" rx="1.5"/><path d="M8 8h8M8 14h8"/></svg>'
  };

  var PRODUCTS = [
    { icon:"passenger", name:"Passenger Elevator", desc:"Smooth, energy-efficient lifts for residential and commercial buildings.", tags:["Smooth Ride","Low Noise","Energy Efficient"], extra:"Available in 6–20 passenger capacities with automatic doors, LED cabin lighting and emergency backup power." },
    { icon:"hospital", name:"Hospital Elevator", desc:"Wide-door stretcher-friendly lifts built for critical care movement.", tags:["Stretcher Size","Anti-Bacterial","Silent Motor"], extra:"Designed for trolley and stretcher access with anti-bacterial panels and ultra-smooth start/stop for patient comfort." },
    { icon:"goods", name:"Goods Lift", desc:"Heavy-duty freight elevators engineered for industrial payloads.", tags:["Heavy Duty","1000kg+","Rugged Build"], extra:"Reinforced cabin flooring and industrial-grade drive systems rated for repeated heavy-load cycles." },
    { icon:"capsule", name:"Capsule Lift", desc:"Panoramic glass capsule lifts that become a design centrepiece.", tags:["360° Glass","Statement Design","LED Accents"], extra:"Full or half-round glass cabins with ambient LED lighting — ideal for malls, hotels and atrium lobbies." },
    { icon:"home", name:"Home Lift", desc:"Compact, elegant lifts designed for bungalows and duplex homes.", tags:["Space Saving","Whisper Quiet","Custom Finish"], extra:"Small shaft footprint options, custom cabin interiors, and whisper-quiet operation suited for family homes." },
    { icon:"mrl", name:"MRL Elevator", desc:"Machine-room-less elevators that save valuable building space.", tags:["No Machine Room","Compact","Efficient"], extra:"Ideal for buildings with limited headroom — full performance without a dedicated machine room." },
    { icon:"hydraulic", name:"Hydraulic Lift", desc:"Reliable low-rise lifts with smooth hydraulic drive systems.", tags:["Low-Rise","Smooth Drive","Cost Effective"], extra:"A cost-effective choice for low-rise buildings, offering smooth hydraulic operation and easy maintenance." },
    { icon:"car", name:"Car Lift", desc:"Automated vertical car parking lifts for space-constrained sites.", tags:["Auto Parking","Heavy Load","Compact Footprint"], extra:"Engineered for basements and multi-level parking structures, maximizing vehicle capacity per square foot." },
    { icon:"escalator", name:"Escalator", desc:"High-traffic escalators for malls, metros and commercial hubs.", tags:["High Traffic","Durable","Safety Sensors"], extra:"Built for continuous high-footfall use with integrated safety sensors and low-maintenance components." },
    { icon:"dumbwaiter", name:"Dumbwaiter Lift", desc:"Compact service lifts for kitchens, restaurants and libraries.", tags:["Compact","Service Use","Easy Install"], extra:"A space-efficient solution for moving food, documents or supplies between floors quickly and safely." }
  ];

  function buildProducts(){
    var grid = document.getElementById("productGrid");
    if (!grid) return;
    var html = PRODUCTS.map(function(p, i){
      var tags = p.tags.map(function(t){ return '<span class="pf-tag">'+t+'</span>'; }).join("");
      return (
        '<article class="product-card" data-reveal data-reveal-delay="'+(i % 3)+'">' +
          '<div class="product-media">' + (ICONS[p.icon] || "") + '</div>' +
          '<h3>' + p.name + '</h3>' +
          '<p class="desc">' + p.desc + '</p>' +
          '<div class="product-features">' + tags + '</div>' +
          '<button type="button" class="read-more" data-toggle>Read More</button>' +
          '<div class="product-extra">' + p.extra + '</div>' +
        '</article>'
      );
    }).join("");
    grid.innerHTML = html;

    grid.querySelectorAll("[data-toggle]").forEach(function(btn){
      btn.addEventListener("click", function(){
        var card = btn.closest(".product-card");
        var expanded = card.classList.toggle("expanded");
        btn.textContent = expanded ? "Show Less" : "Read More";
      });
    });

    // trigger reveal for dynamically injected cards
    revealOnScroll();
  }

  /* ---------- Project data + render ---------- */
  var PROJECT_ICON = '<svg viewBox="0 0 120 90" width="70" height="70"><rect x="10" y="8" width="100" height="74" rx="6" fill="rgba(255,255,255,.15)"/><rect x="24" y="20" width="20" height="50" rx="3" fill="rgba(255,255,255,.9)"/><rect x="50" y="34" width="20" height="36" rx="3" fill="rgba(255,255,255,.9)"/><rect x="76" y="14" width="20" height="56" rx="3" fill="rgba(255,255,255,.9)"/></svg>';

  var PROJECTS = [
    { name:"Lakeview Residency", category:"Residential", location:"Whitefield, Bangalore", type:"Home Lift", year:"2023", tall:true },
    { name:"Cascade Business Park", category:"Commercial", location:"Outer Ring Road, Bangalore", type:"MRL Elevator", year:"2022" },
    { name:"Sri Sai Steel Works", category:"Industrial", location:"Nanjangud, Mysore", type:"Goods Lift", year:"2021", tall:true },
    { name:"Trinity Multi-Speciality Hospital", category:"Hospitals", location:"Vijayanagar, Mysore", type:"Hospital Elevator", year:"2023" },
    { name:"Grand Kaveri Mall", category:"Malls", location:"Hassan Town, Hassan", type:"Capsule Lift", year:"2022", tall:true },
    { name:"Coorg Hillside Resort", category:"Hotels", location:"Madikeri, Kodagu", type:"Passenger Elevator", year:"2020" },
    { name:"Nexus Corporate Tower", category:"Offices", location:"Electronic City, Bangalore", type:"MRL Elevator", year:"2024", tall:true },
    { name:"Palm Meadows Villas", category:"Residential", location:"Yelahanka, Bangalore", type:"Home Lift", year:"2021" },
    { name:"Hassan District Hospital Annex", category:"Hospitals", location:"B.M. Road, Hassan", type:"Hospital Elevator", year:"2022" },
    { name:"Kodagu Spice Hotel", category:"Hotels", location:"Virajpet, Kodagu", type:"Passenger Elevator", year:"2023", tall:true },
    { name:"Vismaya Shopping Centre", category:"Malls", location:"Kuvempunagar, Mysore", type:"Escalator", year:"2021" },
    { name:"Precision Auto Components", category:"Industrial", location:"Peenya, Bangalore", type:"Goods Lift", year:"2020" }
  ];

  function buildProjects(){
    var grid = document.getElementById("projectGrid");
    var filterBar = document.getElementById("filterBar");
    if (!grid) return;

    function render(filter){
      var items = filter === "all" ? PROJECTS : PROJECTS.filter(function(p){ return p.category === filter; });
      grid.innerHTML = items.map(function(p, i){
        return (
          '<div class="project-card" data-reveal data-reveal-delay="' + (i % 3) + '">' +
            '<div class="project-media" style="background:linear-gradient(135deg,#C1121F,#E63946);height:' + (p.tall ? "230px" : "170px") + ';">' +
              '<span class="project-category">' + p.category + '</span>' +
              PROJECT_ICON +
            '</div>' +
            '<div class="project-body">' +
              '<h4>' + p.name + '</h4>' +
              '<div class="project-meta">' +
                '<span>📍 ' + p.location + '</span>' +
                '<span>🛗 ' + p.type + '</span>' +
                '<span>📅 ' + p.year + '</span>' +
              '</div>' +
            '</div>' +
          '</div>'
        );
      }).join("");
      revealOnScroll();
    }

    render("all");

    if (filterBar){
      filterBar.addEventListener("click", function(e){
        var btn = e.target.closest(".filter-btn");
        if (!btn) return;
        filterBar.querySelectorAll(".filter-btn").forEach(function(b){ b.classList.remove("active"); });
        btn.classList.add("active");
        render(btn.getAttribute("data-filter"));
      });
    }
  }

  /* ---------- Product 3D tilt on hover ---------- */
  function productTilt(){
    document.addEventListener("mousemove", function(e){
      var card = e.target.closest && e.target.closest(".product-card");
      if (!card) return;
      var rect = card.getBoundingClientRect();
      var x = (e.clientX - rect.left) / rect.width - 0.5;
      var y = (e.clientY - rect.top) / rect.height - 0.5;
      card.style.transform = "perspective(700px) rotateY(" + (x * 8) + "deg) rotateX(" + (y * -8) + "deg) translateY(-4px)";
    });
    document.addEventListener("mouseout", function(e){
      var card = e.target.closest && e.target.closest(".product-card");
      if (card) card.style.transform = "";
    });
  }

  /* ---------- Hero mouse parallax ---------- */
  function heroParallax(){
    var scene = document.getElementById("shaftScene");
    var hero = document.querySelector(".hero");
    if (!scene || !hero) return;
    hero.addEventListener("mousemove", function(e){
      var rect = hero.getBoundingClientRect();
      var x = (e.clientX - rect.left) / rect.width - 0.5;
      var y = (e.clientY - rect.top) / rect.height - 0.5;
      scene.style.transform = "translate(" + (x * 14) + "px," + (y * 10) + "px)";
    });
    hero.addEventListener("mouseleave", function(){
      scene.style.transform = "translate(0,0)";
    });
  }

  /* ---------- Floor badge synced roughly with cabin travel ---------- */
  function floorBadgeSync(){
    var badge = document.getElementById("floorBadge");
    if (!badge) return;
    var floors = ["G", "1", "2", "3", "4", "5"];
    var i = 0;
    setInterval(function(){
      i = (i + 1) % floors.length;
      badge.textContent = floors[i];
    }, 1300);
  }

  /* ---------- Contact form (client-side only) ---------- */
  function contactFormHandler(){
    var form = document.getElementById("contactForm");
    var note = document.getElementById("formNote");
    if (!form) return;
    form.addEventListener("submit", function(e){
      e.preventDefault();
      if (!form.checkValidity()){
        note.textContent = "Please fill in all required fields correctly.";
        note.style.color = "#C1121F";
        form.reportValidity();
        return;
      }
      note.style.color = "#C1121F";
      note.textContent = "Thank you! Our team will contact you shortly.";
      form.reset();
      // NOTE: connect this form to a backend endpoint or service
      // (e.g. Formspree, EmailJS, or your own API) to actually send the enquiry.
    });
  }

  /* ---------- Back to top ---------- */
  function backToTop(){
    var btn = document.getElementById("topBtn");
    if (!btn) return;
    window.addEventListener("scroll", function(){
      if (window.scrollY > 500) btn.classList.add("show");
      else btn.classList.remove("show");
    }, { passive:true });
    btn.addEventListener("click", function(){
      window.scrollTo({ top:0, behavior:"smooth" });
    });
  }

  /* ---------- Call button ---------- */
  function callButton(){
    var btn = document.getElementById("callBtn");
    if (!btn) return;
    btn.addEventListener("click", function(){
      window.location.href = "tel:+919742123838";
    });
  }

})();
